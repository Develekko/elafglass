//$(window).blur(function() {
  //  document.title = 'Elaf Glass';
//})

//$(window).focus(function() {
 //   document.title = 'Elaf Glass' ;
//})

